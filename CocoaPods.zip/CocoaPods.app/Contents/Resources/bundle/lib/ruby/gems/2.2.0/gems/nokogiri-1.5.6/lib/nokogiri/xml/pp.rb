require 'nokogiri/xml/pp/node'
require 'nokogiri/xml/pp/character_data'
