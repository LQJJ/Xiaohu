#ifndef NOKOGIRI_XML_ATTRIBUTE_DECL
#define NOKOGIRI_XML_ATTRIBUTE_DECL

#include <nokogiri.h>

void init_xml_attribute_decl();

extern VALUE cNokogiriXmlAttributeDecl;
#endif
