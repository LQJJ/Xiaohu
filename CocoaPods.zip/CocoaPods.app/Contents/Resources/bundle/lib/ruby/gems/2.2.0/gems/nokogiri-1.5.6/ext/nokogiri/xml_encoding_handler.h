#ifndef NOKOGIRI_XML_ENCODING_HANDLER
#define NOKOGIRI_XML_ENCODING_HANDLER

#include <nokogiri.h>

void init_xml_encoding_handler();

#endif
