#ifndef NOKOGIRI_HTML_DOCUMENT
#define NOKOGIRI_HTML_DOCUMENT

#include <nokogiri.h>

void init_html_document();

extern VALUE cNokogiriHtmlDocument ;

#endif
