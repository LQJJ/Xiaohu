#ifndef NOKOGIRI_XML_READER
#define NOKOGIRI_XML_READER

#include <nokogiri.h>

void init_xml_reader();

extern VALUE cNokogiriXmlReader;

#endif
