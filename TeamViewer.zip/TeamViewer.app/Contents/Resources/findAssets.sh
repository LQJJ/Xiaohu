#!/bin/sh

resourcePath="Resource/OSX"
assetPath="Resource/OSX/Images"
userInterfacePath="OSX/TVUserInterface"
patternFilePath="${SRCROOT}/../patterns.txt"

assetNames=()

# Build a list of all asset
echo "" > "${patternFilePath}"
for file in $(find "${assetPath}" -type d -name *.imageset)
do
	filename=$(basename ${file})
	echo "\"${filename%.*}\"" >> "${patternFilePath}"
	assetNames+=("\"${filename%.*}\"")
done
# Remove empty strings and lines from the patterns file
sed -i ".tmp" 's/^ *//; s/ *$//; /^$/d' "${patternFilePath}"

# Search for asset names in source code files and xibs.
foundAssetNames=()

findAssets()
{
	local __file="${1}"
	for fileWithImages in $(grep -f "${patternFilePath}" -m 1 -o "${__file}" --exclude *.pbxproj*)
	do
		for currentAssetName in "${assetNames[@]}"
		do
			for line in $(grep "${currentAssetName}" -o "${__file}" --exclude *.pbxproj*)
			do
				foundAssetNames+=("${line##*:}")
			done
		done
	done
}

for currentFile in $(find "${SRCROOT}" -type f -name *.m* ! -path "${SRCROOT}*iOS/*")
do
	findAssets "${currentFile}"
done

for xib in $(find "${resourcePath}/XIB" -type f -name "*.xib")
do
	findAssets "${xib}"
done

for xib in $(find "${userInterfacePath}" -type f -name "*.xib")
do
	findAssets "${xib}"
done

# Sort the lists
sortedAssetNames=($(for each in ${assetNames[@]}; do echo $each; done | sort | uniq))
sortedFoundAssetNames=($(for each in ${foundAssetNames[@]}; do echo $each; done | sort | uniq))

# Find assets that are not used.
for currentAssetName in "${sortedAssetNames[@]}"
do
	notfound="${currentAssetName}"
	for currentFoundAssetNames in "${sortedFoundAssetNames[@]}"
	do
		if [ $currentAssetName == $currentFoundAssetNames ]; then
			notfound="Found"
			continue
		fi
	done

	if [ $currentAssetName == $notfound ]; then
		cleanAssetName=$(echo "${currentAssetName}" | sed "s|\"||g")
		for file in $(find "${assetPath}" -type d -name "${cleanAssetName}.imageset")
		do
			echo "${SRCROOT}/${file}:0:0: warning: Asset named '${cleanAssetName}' not used in code or xib files!"
		done
	fi
done
