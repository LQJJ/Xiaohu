-----------------------------------------------------
How to build all the js and css files in 3 easy steps
-----------------------------------------------------


Step 1: install yarn from https://yarnpkg.com/en/

Step 2: run Build.bat

Step 3: profit!