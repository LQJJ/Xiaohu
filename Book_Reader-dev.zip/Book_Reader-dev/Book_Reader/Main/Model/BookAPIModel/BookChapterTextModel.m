//
//  BookChapterTextModel.m
//  Book_Reader
//
//  Created by hhuua on 2018/6/25.
//  Copyright © 2018年 hhuua. All rights reserved.
//

#import "BookChapterTextModel.h"

@implementation BookChapterTextModel

@end
