//
//  BooksourceModel.m
//  Book_Reader
//
//  Created by hhuua on 2018/7/19.
//  Copyright © 2018年 hhuua. All rights reserved.
//

#import "BooksourceModel.h"

@implementation BooksourceModel

@end
