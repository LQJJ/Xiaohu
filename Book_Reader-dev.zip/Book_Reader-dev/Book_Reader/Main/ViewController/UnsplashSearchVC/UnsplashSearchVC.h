//
//  UnsplashSearchVC.h
//  Book_Reader
//
//  Created by hhuua on 2019/3/5.
//  Copyright © 2019 hhuua. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UnsplashSearchVC : UISearchController

- (void)reloadView;

@end

NS_ASSUME_NONNULL_END
