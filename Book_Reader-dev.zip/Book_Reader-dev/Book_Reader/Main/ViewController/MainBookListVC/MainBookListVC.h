//
//  MainBookListVC.h
//  Book_Reader
//
//  Created by hhuua on 2018/7/3.
//  Copyright © 2018年 hhuua. All rights reserved.
//

#import "HYBaseViewController.h"

/* 展示收藏书籍的"首页"*/
@interface MainBookListVC : HYBaseViewController



@end
