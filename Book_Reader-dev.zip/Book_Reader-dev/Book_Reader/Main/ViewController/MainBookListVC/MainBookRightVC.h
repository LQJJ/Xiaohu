//
//  MainBookRightVC.h
//  Book_Reader
//
//  Created by hhuua on 2018/7/3.
//  Copyright © 2018年 hhuua. All rights reserved.
//

#import "HYBaseViewController.h"


@interface MainBookRightVC : HYBaseViewController

@end
