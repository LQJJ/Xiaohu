//
//  BookSearchVC.h
//  Book_Reader
//
//  Created by hhuua on 2018/6/28.
//  Copyright © 2018年 hhuua. All rights reserved.
//

#import "HYBaseViewController.h"

/* 书本搜索页面*/
@interface BookSearchVC : HYBaseViewController

@end
