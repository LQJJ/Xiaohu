//
//  HYHTTPSessionManager.h
//  Book_Reader
//
//  Created by hhuua on 2018/6/25.
//  Copyright © 2018年 hhuua. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>

@interface HYHTTPSessionManager : AFHTTPSessionManager

@end
