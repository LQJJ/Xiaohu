//
//  BookReadLocalVM.h
//  Book_Reader
//
//  Created by hhuua on 2018/6/26.
//  Copyright © 2018年 hhuua. All rights reserved.
//

#import <Foundation/Foundation.h>

/* 本地书源或网络下载书源的ViewModel*/
@interface BookReadLocalVM : NSObject

@end
