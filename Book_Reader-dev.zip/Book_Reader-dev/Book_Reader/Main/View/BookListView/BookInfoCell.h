//
//  BookInfoCell.h
//  Book_Reader
//
//  Created by hhuua on 2018/6/29.
//  Copyright © 2018年 hhuua. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BookInfoModel.h"
/* 书本信息cell*/
@interface BookInfoCell : UITableViewCell

@property (nonatomic,strong) BookInfoModel* model;

@end
