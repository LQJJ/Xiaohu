//
//  MainBookRightCell.h
//  Book_Reader
//
//  Created by hhuua on 2018/7/3.
//  Copyright © 2018年 hhuua. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainBookRightCell : UITableViewCell

- (void)changeBackColor:(UIColor*)color Image:(UIImage*)image Name:(NSString*)name;

@end
