//
//  MainBookInfoCell.h
//  Book_Reader
//
//  Created by hhuua on 2018/7/3.
//  Copyright © 2018年 hhuua. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BookSaveInfoModel.h"

@interface MainBookInfoCell : UITableViewCell

@property (nonatomic,strong) BookSaveInfoModel* model;

@end
