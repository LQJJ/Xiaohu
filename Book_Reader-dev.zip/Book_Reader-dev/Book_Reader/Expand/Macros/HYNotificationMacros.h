//
//  TWNotificationMacros.h
//
//  Created by hhuua on 2017/8/28.
//  Copyright © 2017年 hhuua. All rights reserved.
//

#ifndef TWNotificationMacros_h
#define TWNotificationMacros_h

#define kNotifyAppDidBecomeActive @"HYNotify_applicationDidBecomeActive"
#define kNotifyAppDidEnterBackground @"HYNotify_applicationDidEnterBackground"

#define kNotifyReadContentTouchEnd @"HYNotifyReadContentTouchEnd"
#define kNotifyReadChangeBookSource @"HYReadChangeBookSource"

#endif /* TWNotificationMacros_h */
