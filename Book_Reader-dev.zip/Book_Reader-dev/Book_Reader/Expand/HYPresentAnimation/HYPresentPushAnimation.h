//
//  HYPresentPushAnimation.h
//
//  Created by hhuua on 2017/8/21.
//  Copyright © 2017年 hhuua. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * 用于在模态时使用Navi的push动画
 */
@interface HYPresentPushAnimation : NSObject<UIViewControllerAnimatedTransitioning>

@end
