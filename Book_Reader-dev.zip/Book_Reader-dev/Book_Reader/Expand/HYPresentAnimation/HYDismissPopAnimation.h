//
//  HYDismissPopAnimation.h
//
//  Created by hhuua on 2017/8/21.
//  Copyright © 2017年 hhuua. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * 用于在Dismiss时实现Navi的pop动画
 */
@interface HYDismissPopAnimation : NSObject<UIViewControllerAnimatedTransitioning>


@end
