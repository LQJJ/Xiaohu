//
//  UIColor+random.h
//  Book_Reader
//
//  Created by hhuua on 2018/6/26.
//  Copyright © 2018年 hhuua. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (random)

+ (UIColor *)randomColor;
+ (UIColor *)randomLightColor;

@end
