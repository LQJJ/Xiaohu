declare module 'electron-context-menu' {
    function registerContextMenu(options: {}): void;
    export = registerContextMenu;
}