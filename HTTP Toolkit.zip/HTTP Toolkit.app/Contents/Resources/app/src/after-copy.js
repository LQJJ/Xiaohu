require('ts-node/register');
module.exports = require('./after-copy-insert-server');