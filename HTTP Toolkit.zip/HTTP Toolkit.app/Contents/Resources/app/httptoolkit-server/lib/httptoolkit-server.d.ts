/// <reference types="node" />
import * as events from 'events';
import { HtkConfig } from './config';
export declare class HttpToolkitServer extends events.EventEmitter {
    private graphql;
    constructor(config: HtkConfig);
    start(): Promise<void>;
}
