export declare function runHTK(options: {
    configPath?: string;
}): Promise<void>;
