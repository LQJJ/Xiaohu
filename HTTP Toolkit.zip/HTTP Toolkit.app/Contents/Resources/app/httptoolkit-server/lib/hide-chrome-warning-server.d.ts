export declare class HideChromeWarningServer {
    private server;
    completedPromise: Promise<void>;
    start(targetUrl: string): Promise<void>;
    readonly host: string;
    readonly hideWarningUrl: string;
    stop(): Promise<void>;
}
