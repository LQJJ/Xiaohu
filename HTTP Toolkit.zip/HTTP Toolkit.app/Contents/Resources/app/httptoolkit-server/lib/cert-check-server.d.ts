import { HttpsPathOptions } from 'mockttp/dist/util/tls';
export declare class CertCheckServer {
    private config;
    constructor(config: {
        https: HttpsPathOptions;
    });
    private server;
    start(targetUrl: string): Promise<void>;
    readonly host: string;
    readonly checkCertUrl: string;
    waitForSuccess(): Promise<void>;
    stop(): Promise<void>;
}
