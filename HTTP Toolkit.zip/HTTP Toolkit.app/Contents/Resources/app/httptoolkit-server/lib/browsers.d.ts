/// <reference types="@james-proxy" />
import * as getBrowserLauncher from '@james-proxy/james-browser-launcher';
import { BrowserInstance } from '@james-proxy/james-browser-launcher';
export { BrowserInstance };
export declare const getAvailableBrowsers: (configPath: string) => Promise<getBrowserLauncher.Browser[]>;
export declare const launchBrowser: (url: string, options: getBrowserLauncher.LaunchOptions, configPath: string) => Promise<getBrowserLauncher.BrowserInstance>;
