export declare function delay(durationMs: number): Promise<void>;
