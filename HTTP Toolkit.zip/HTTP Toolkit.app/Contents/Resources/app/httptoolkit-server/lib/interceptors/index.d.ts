import * as _ from 'lodash';
import { HtkConfig } from '../config';
export interface Interceptor {
    id: string;
    version: string;
    isActivable(): Promise<boolean>;
    isActive(proxyPort: number): boolean;
    activate(proxyPort: number, options?: any): Promise<void>;
    deactivate(proxyPort: number, options?: any): Promise<void>;
}
export declare function buildInterceptors(config: HtkConfig): _.Dictionary<Interceptor>;
