import { HtkConfig } from '../config';
export declare class FreshFirefox {
    private config;
    id: string;
    version: string;
    constructor(config: HtkConfig);
    isActive(proxyPort: number): boolean;
    isActivable(): Promise<boolean>;
    activate(proxyPort: number): Promise<void>;
    deactivate(proxyPort: number): Promise<void>;
}
