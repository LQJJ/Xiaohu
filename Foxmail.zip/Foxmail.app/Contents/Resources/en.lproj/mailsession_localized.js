foxmail.localizable = {
    'show_details' : "More Info",
    'hide_details' : "Hide Info",
    'show_quote' : "Show trimmed content↓",
    'hide_quote' : "Hide expanded content↑",
    'gesture_next' : "",
    'gesture_prev' : ""
};
