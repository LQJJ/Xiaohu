foxmail.localizable = {
    'show_details' : "详细信息",
    'hide_details' : "隐藏信息",
    'show_quote' : "显示引用↓",
    'hide_quote' : "隐藏引用↑",
    'gesture_next' : "",
    'gesture_prev' : ""
};
