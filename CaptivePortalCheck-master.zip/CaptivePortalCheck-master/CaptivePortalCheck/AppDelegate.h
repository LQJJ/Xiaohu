//
//  AppDelegate.h
//  CaptivePortalCheck
//
//  Created by 谭真 on 2017/9/6.
//  Copyright © 2017年 Alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

