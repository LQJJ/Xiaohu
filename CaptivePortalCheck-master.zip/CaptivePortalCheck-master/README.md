# CaptivePortalCheck

一个检测当前WIFI是否需要认证的小Demo，详见博客：[为你的App增加WIFI认证检测，让用户体验更加丝滑](http://www.jianshu.com/p/a5f179bb46af)

<img src="http://upload-images.jianshu.io/upload_images/1171135-df69a384d02be371.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240" width="70%" height="70%">
