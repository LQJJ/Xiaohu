"use strict";
cc._RF.push(module, '52f53vMPsFAjpzaXvD7gqHb', 'close');
// Script/close.js

"use strict";

cc.Class({
    extends: cc.Component,

    onLoad: function onLoad() {},

    close: function close() {
        cc.director.end();
    }

});

cc._RF.pop();