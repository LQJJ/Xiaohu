"use strict";
cc._RF.push(module, 'a668bPn8TJM7qttK45YDX2+', 'reset');
// Script/reset.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {},

    reset: function reset() {
        cc.director.loadScene("first");
    }

});

cc._RF.pop();