"use strict";
cc._RF.push(module, '69937FZ5GBKx4tfCnUXS+kQ', 'bg');
// Script/bg.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        hero: {
            default: null,
            type: cc.Node
        },

        bg: {
            default: null,
            type: cc.Node
        }
    },

    onLoad: function onLoad() {},

    update: function update(dt) {

        if (this.hero.x > 350) {
            if (this.bg.x < -1920) {
                this.bg.x = -1920;
                this.hero.x = 350;
            } else if (this.bg.x >= -1920) {
                this.bg.x -= this.hero.x - 350;
                this.hero.x = 350;
            }
        } else if (this.hero.x < -350) {
            if (this.bg.x < -480) {
                this.bg.x -= this.hero.x + 350;
                this.hero.x = -350;
            } else if (this.bg.x >= -480) {
                this.bg.x = -480;
                this.hero.x = -350;
            }
        }
    }
});

cc._RF.pop();