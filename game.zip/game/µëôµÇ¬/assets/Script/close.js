cc.Class({
    extends: cc.Component,

    onLoad: function () {

    },
    
    close: function () {
        cc.director.end();
    },

});
