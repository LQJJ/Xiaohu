cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    onLoad: function () {

    },
    
    reset: function () {
        cc.director.loadScene("first");
    },

});
