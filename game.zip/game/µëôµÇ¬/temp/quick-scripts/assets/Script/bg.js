(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/bg.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '69937FZ5GBKx4tfCnUXS+kQ', 'bg', __filename);
// Script/bg.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        hero: {
            default: null,
            type: cc.Node
        },

        bg: {
            default: null,
            type: cc.Node
        }
    },

    onLoad: function onLoad() {},

    update: function update(dt) {

        if (this.hero.x > 350) {
            if (this.bg.x < -1920) {
                this.bg.x = -1920;
                this.hero.x = 350;
            } else if (this.bg.x >= -1920) {
                this.bg.x -= this.hero.x - 350;
                this.hero.x = 350;
            }
        } else if (this.hero.x < -350) {
            if (this.bg.x < -480) {
                this.bg.x -= this.hero.x + 350;
                this.hero.x = -350;
            } else if (this.bg.x >= -480) {
                this.bg.x = -480;
                this.hero.x = -350;
            }
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=bg.js.map
        