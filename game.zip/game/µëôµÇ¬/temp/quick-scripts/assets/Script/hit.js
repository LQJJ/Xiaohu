(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/hit.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b2cccxLrdBCjZJ19byMzjSM', 'hit', __filename);
// Script/hit.js

"use strict";

var hero = require("hero");
var monster = require("monster");
cc.Class({
    extends: cc.Component,

    properties: {
        view: {
            default: null,
            type: cc.Node
        },

        label: {
            default: null,
            type: cc.Label
        }
    },

    onLoad: function onLoad() {},

    onEnable: function onEnable() {
        cc.director.getCollisionManager().enabled = true;
    },

    onDisable: function onDisable() {
        cc.director.getCollisionManager().enabled = false;
    },

    onCollisionEnter: function onCollisionEnter(other, self) {
        if (self.tag === 0) {
            this.view.active = true;
            this.label.string = "you win";
            hero.removeAll();
            monster.stopAll();
        } else {
            this.view.active = true;
            this.label.string = "you lose";
            hero.removeAll();
            monster.stopAll();
        }
    }

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=hit.js.map
        