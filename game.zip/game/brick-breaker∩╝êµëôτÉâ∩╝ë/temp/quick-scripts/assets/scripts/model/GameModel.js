(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/model/GameModel.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ac11fh/SXFFzZAzJ57bmcvY', 'GameModel', __filename);
// scripts/model/GameModel.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        score: 0,
        bricksNumber: 0
    },

    init: function init() {
        this.score = 0;
        this.bricksNumber = 50;
    },
    addScore: function addScore(score) {
        this.score += score;
    },
    minusBrick: function minusBrick(n) {
        this.bricksNumber -= n;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GameModel.js.map
        