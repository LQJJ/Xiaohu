(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scripts/Stair.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '43ed81/iOxDKZ01LwJQfAmX', 'Stair', __filename);
// Scripts/Stair.js

"use strict";

var tmpPlayer = require("Player");
cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {
    // },

    start: function start() {},


    // update (dt) {
    // },

    onCollisionExit: function onCollisionExit(other, self) {
        this.scheduleOnce(function () {
            this.stairIsUsed();
        }, 1.0);
    },

    stairIsUsed: function stairIsUsed() {
        var _this = this;

        var goAction = cc.moveBy(1.0, cc.p(0, -600));
        this.node.runAction(goAction);
        setTimeout(function () {
            if (cc.isValid(_this.node)) {
                _this.node.destroy();
            }
        }, 1200);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Stair.js.map
        