"use strict";
cc._RF.push(module, '43ed81/iOxDKZ01LwJQfAmX', 'Stair');
// Scripts/Stair.js

"use strict";

var tmpPlayer = require("Player");
cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {
    // },

    start: function start() {},


    // update (dt) {
    // },

    onCollisionExit: function onCollisionExit(other, self) {
        this.scheduleOnce(function () {
            this.stairIsUsed();
        }, 1.0);
    },

    stairIsUsed: function stairIsUsed() {
        var _this = this;

        var goAction = cc.moveBy(1.0, cc.p(0, -600));
        this.node.runAction(goAction);
        setTimeout(function () {
            if (cc.isValid(_this.node)) {
                _this.node.destroy();
            }
        }, 1200);
    }
});

cc._RF.pop();