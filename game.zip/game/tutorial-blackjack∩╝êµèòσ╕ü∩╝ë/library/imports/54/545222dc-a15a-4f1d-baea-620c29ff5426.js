"use strict";
cc._RF.push(module, '54522LcoVpPHbrqYgwp/1Qm', 'AssetMng');
// scripts/AssetMng.js

"use strict";

var AssetMng = cc.Class({
    extends: cc.Component,

    properties: {
        texBust: cc.SpriteFrame,
        texCardInfo: cc.SpriteFrame,
        texCountdown: cc.SpriteFrame,
        texBetCountdown: cc.SpriteFrame,
        playerPhotos: [cc.SpriteFrame]
    }
});

cc._RF.pop();